/*
Theme Name: Archi
Theme URI: http://archiwp.com/
Author: OceanThemes
Author URI: http://oceanthemes.net/
Description: Archi specially made for Interior Design services, Dining Room, Exterior Design, Kitchen Design, Living Room Design, Master Bedroom Design, Residential Design, Furniture Design, Office Design, Commercial Design, Hospital Design, Cottage, Architecture, contractor, construction, building, Construction & Business etc� . Archi help you to build beauty and modern website in no time. Archi has beauty design and bunch of features to make your website stand out of crowd.
Version: 3.6.9.8
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Tags: two-columns, three-columns, left-sidebar, right-sidebar, custom-background, custom-header, custom-menu, editor-style, featured-images, flexible-header, full-width-template, microformats, post-formats, rtl-language-support, sticky-post, theme-options, translation-ready, accessibility-ready
Text Domain: archi
Domain Path: /languages

This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.
*/